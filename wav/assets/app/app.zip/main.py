import io
import flet
import numpy
import base64
import scipy.io.wavfile as wavfile

def main(page: flet.Page):
    def download(e):    
        data = numpy.sin(2 * numpy.pi * 220 * numpy.arange(2 * 22050) / 22050)
        buffer = io.BytesIO()
        wavfile.write(buffer, 22050, data)
        data = base64.b64encode(buffer.getvalue()).decode("utf8")
        data = f"data:audio/wav;base64,{data}"
        page.launch_url(data)

    page.add(flet.SafeArea(
        flet.Container(
            flet.ElevatedButton("Download", on_click=download)
        )
    ))

flet.app(main)
