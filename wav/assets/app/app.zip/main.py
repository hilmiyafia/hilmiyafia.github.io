import flet
import base64
import numpy
import io
import scipy.io.wavfile as wavfile

def main(page: flet.Page):
    data = numpy.sin(2 * numpy.pi * 220 * numpy.arange(2 * 22050) / 22050)
    buffer = io.BytesIO()
    wavfile.write(buffer, 22050, data)
    data = base64.b64encode(buffer.getvalue())
    data = data.decode("utf8")
    data = f"data:application/octet-stream;base64,{data}"
    page.add(flet.SafeArea(flet.ElevatedButton(
        "Save", 
        url=data,
        url_target=flet.UrlTarget.BLANK,
        data={"download": "export.wav"},
    )))

flet.app(main, view=flet.AppView.WEB_BROWSER)


"""
@app.get("/download")
def download():
    buffer = BytesIO(bytes("test\n", "utf8"))
    buffer.seek(0)
    return StreamingResponse(
        buffer, 
        media_type="application/octet-stream", 
        headers={'Content-Disposition': f'filename=export.txt'},
    )

if __name__ == "__main__":
    uvicorn.run("main:app")
"""