import flet
from fastapi.responses import StreamingResponse
from io import BytesIO
import flet.fastapi

def main(page: flet.Page):
    page.add(flet.SafeArea(flet.ElevatedButton(
        "Save", 
        on_click=lambda _: page.launch_url("/download"),
    )))

app = flet.fastapi.app(main)

@app.get("/download")
def download():
    buffer = BytesIO(bytes("test\n", "utf8"))
    buffer.seek(0)
    return StreamingResponse(
        buffer, 
        media_type="application/octet-stream", 
        headers={'Content-Disposition': f'filename=export.txt'},
    )
