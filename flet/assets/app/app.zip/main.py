import flet as ft
import numpy


def main(page: ft.Page):
    counter = ft.Text("0", size=50, data=0)
    random = ft.Text("0 - 0", size=50)

    def increment_click(e):
        counter.data += 1
        counter.value = str(counter.data)
        random.value = f"{numpy.random.rand():.2f} - {numpy.random.rand():.2f}"
        counter.update()
        random.update()

    page.floating_action_button = ft.FloatingActionButton(
        icon=ft.Icons.ADD, on_click=increment_click
    )

    page.add(
        ft.SafeArea(
            ft.Container(
                ft.Column(
                    [random, counter], 
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                alignment=ft.alignment.center,
            ),
            expand=True,
        )
    )


ft.app(main)
