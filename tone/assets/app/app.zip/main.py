import io
import wave
import flet
import numpy


def bytes_to_base64(text):
    table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    pad = "="
    result = ""
    for i in range(0, len(text), 3):
        buffer = text[i] << 16
        if i + 1 < len(text):
            buffer += text[i + 1] << 8
        if i + 2 < len(text):
            buffer += text[i + 2]
        result += table[(buffer >> 18) & 63]
        result += table[(buffer >> 12) & 63]
        if i + 1 < len(text):
            result += table[(buffer >> 6) & 63]
        else:
            result += pad
        if i + 2 < len(text):
            result += table[buffer & 63]
        else:
            result += pad
    return result
        

def wav_to_iobytes(target, data, framerate):
    data = numpy.clip(numpy.round(data * 32768), -32768, 32768).astype("<h")
    with wave.open(target, "wb") as file:
        file.setnchannels(1)
        file.setsampwidth(2)
        file.setframerate(framerate)
        file.writeframes(data)


def main(page: flet.Page):
    def download(e):
        pitch = float(frequency.value)
        data = numpy.sin(2 * numpy.pi * pitch * numpy.arange(2 * 22050) / 22050) * 0.5
        buffer = io.BytesIO()
        wav_to_iobytes(buffer, data, 22050)
        data = bytes_to_base64(buffer.getvalue())
        data = f"data:application/octet-stream;base64,{data}"
        page.launch_url(data)

    frequency = flet.TextField("220", label="Frequency (Hz)", width=120)

    page.add(flet.SafeArea(
        flet.Container(
            flet.Column(
                [
                    flet.Text("Tone Generator"),
                    frequency,
                    flet.ElevatedButton("Download", on_click=download),
                ],
                alignment=flet.MainAxisAlignment.CENTER,
                horizontal_alignment=flet.CrossAxisAlignment.CENTER,
            ),
            alignment=flet.Alignment(0, 0),
            expand=1,
        ),
        expand=1,
    ))


flet.app(main)
